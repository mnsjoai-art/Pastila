import { useState, useCallback } from "react";
import Game from "./components/Game";
import StartScreen from "./components/StartScreen";
import GameOver from "./components/GameOver";
import LevelComplete from "./components/LevelComplete";
import { generateLevel } from "./utils/levelGenerator";

export interface Obstacle {
  x: number;
  y: number;
  width: number;
  height: number;
  type: "solid" | "bouncy" | "sticky" | "teleporter";
  angle?: number;
  teleporterId?: number;
}

export interface LevelData {
  id: number;
  name: string;
  obstacles: Obstacle[];
  portal: { x: number; y: number };
  maxBounces: number;
  ballStart: { x: number; y: number };
  theme: {
    primary: string;
    secondary: string;
    accent: string;
    particleColor: string;
    name: string;
  };
}

export interface BodyFact {
  title: string;
  fact: string;
  icon: string;
  category: string;
}

export default function App() {
  const [gameState, setGameState] = useState<"start" | "playing" | "levelcomplete" | "gameover">("start");
  const [currentLevel, setCurrentLevel] = useState(1);
  const [totalScore, setTotalScore] = useState(0);
  const [levelScore, setLevelScore] = useState(0);
  const [level, setLevel] = useState<LevelData | null>(null);
  const [highScore, setHighScore] = useState(0);
  const [currentFact, setCurrentFact] = useState<BodyFact | null>(null);
  const [bouncesUsed, setBouncesUsed] = useState(0);

  const startGame = useCallback(() => {
    setGameState("playing");
    setCurrentLevel(1);
    setTotalScore(0);
    setLevelScore(0);
    setLevel(generateLevel(1));
  }, []);

  const handleLevelComplete = useCallback((bounces: number, score: number) => {
    setBouncesUsed(bounces);
    setTotalScore(prev => prev + score);
    setLevelScore(score);
    
    if (totalScore + score > highScore) {
      setHighScore(totalScore + score);
    }
    
    const fact = getRandomFact();
    setCurrentFact(fact);
    setGameState("levelcomplete");
  }, [totalScore, highScore]);

  const handleNextLevel = useCallback(() => {
    setCurrentLevel(prev => {
      const next = prev + 1;
      setLevel(generateLevel(next));
      return next;
    });
    setGameState("playing");
  }, []);

  const handleGameOver = useCallback(() => {
    setGameState("gameover");
    if (totalScore > highScore) {
      setHighScore(totalScore);
    }
  }, [totalScore, highScore]);

  const restartGame = useCallback(() => {
    setGameState("playing");
    setCurrentLevel(1);
    setTotalScore(0);
    setLevelScore(0);
    setLevel(generateLevel(1));
  }, []);

  return (
    <div className="fixed inset-0 bg-emerald-950 flex flex-col overflow-hidden select-none">
      <div className="flex-1 flex items-center justify-center p-2 sm:p-4">
        <div className="w-full max-w-lg h-full max-h-[800px] flex flex-col">
          {gameState === "start" && (
            <StartScreen 
              onStart={startGame} 
              highScore={highScore}
            />
          )}
          
          {gameState === "playing" && level && (
            <Game
              level={level}
              levelNumber={currentLevel}
              onLevelComplete={handleLevelComplete}
              onGameOver={handleGameOver}
            />
          )}
          
          {gameState === "levelcomplete" && currentFact && (
            <LevelComplete
              level={currentLevel}
              score={levelScore}
              totalScore={totalScore}
              fact={currentFact}
              bouncesUsed={bouncesUsed}
              maxBounces={level?.maxBounces || 25}
              onNextLevel={handleNextLevel}
            />
          )}
          
          {gameState === "gameover" && (
            <GameOver
              score={totalScore}
              level={currentLevel}
              onRestart={restartGame}
              highScore={highScore}
            />
          )}
        </div>
      </div>
    </div>
  );
}

const BODY_FACTS: BodyFact[] = [
  { title: "206 Oase", fact: "Corpul uman adult conține 206 oase. Bebelușii se nasc cu aproximativ 270, dar multe se unesc pe măsură ce creștem!", icon: "🦴", category: "Scheletic" },
  { title: "Cel mai puternic os", fact: "Femurul (osul coapsei) este cel mai puternic os din corp. Poate susține până la 30 de ori greutatea corpului tău!", icon: "💪", category: "Scheletic" },
  { title: "Bătăile inimii", fact: "Inima ta bate aproximativ 100.000 de ori pe zi, pompând aproximativ 7.500 de litri de sânge!", icon: "❤️", category: "Cardiovascular" },
  { title: "Călătoria sângelui", fact: "Un globulă roșie face un circuit complet al corpului tău în doar 20 de secunde!", icon: "🩸", category: "Cardiovascular" },
  { title: "Puterea creierului", fact: "Creierul tău folosește aproximativ 20% din energia ta totală, deși cântărește doar aproximativ 1,4 kg!", icon: "🧠", category: "Nervos" },
  { title: "Neuronii", fact: "Creierul uman conține aproximativ 86 de miliarde de neuroni, fiecare formând mii de conexiuni!", icon: "⚡", category: "Nervos" },
  { title: "Capacitatea pulmonară", fact: "Plămânii tăi conțin aproximativ 300 de milioane de alveole. Dacă ar fi întinse, ar acoperi un teren de tenis!", icon: "🎾", category: "Respirator" },
  { title: "Rata respirației", fact: "Un adult respiră de aproximativ 12-20 de ori pe minut - asta înseamnă peste 20.000 de respirații pe zi!", icon: "🌬️", category: "Respirator" },
  { title: "Numărul de mușchi", fact: "Corpul uman are peste 600 de mușchi! Ei reprezintă aproximativ 40% din greutatea corpului tău.", icon: "💪", category: "Muscular" },
  { title: "Mușchii zâmbetului", fact: "Este nevoie de 17 mușchi pentru a zâmbi și 43 pentru a te încrunta. Așa că zâmbește - e mai ușor!", icon: "😊", category: "Muscular" },
  { title: "Celulele pielii", fact: "Pierzi aproximativ 30.000-40.000 de celule moarte ale pielii în fiecare minut - asta înseamnă aproximativ 4 kg pe an!", icon: "🧴", category: "Piele" },
  { title: "Amprentele digitale", fact: "Nicio două persoane nu au aceleași amprente digitale - nici măcar gemenii identici!", icon: "👆", category: "Piele" },
  { title: "Lungimea ADN-ului", fact: "Dacă ar fi desfășurat, ADN-ul dintr-o celulă s-ar întinde pe 2 metri. Tot ADN-ul din corpul tău ar ajunge la Soare și înapoi de 600 de ori!", icon: "🧬", category: "Genetică" },
  { title: "Numărul de celule", fact: "Corpul tău conține aproximativ 37,2 trilioane de celule. 300 de milioane mor în fiecare minut și sunt înlocuite!", icon: "🔬", category: "Genetică" },
  { title: "Conținutul de apă", fact: "Corpul tău este aproximativ 60% apă. Creierul și inima sunt 73% apă!", icon: "💧", category: "Hidratare" },
  { title: "Mușchii ochiului", fact: "Mușchii ochilor sunt cei mai activi mușchi din corp, mișcându-se de peste 100.000 de ori pe zi!", icon: "👁️", category: "Muscular" },
];

const recentFacts: number[] = [];

function getRandomFact(): BodyFact {
  let availableIndices = BODY_FACTS.map((_, i) => i).filter(i => !recentFacts.includes(i));
  
  if (availableIndices.length === 0) {
    recentFacts.length = 0;
    availableIndices = BODY_FACTS.map((_, i) => i);
  }
  
  const randomIndex = availableIndices[Math.floor(Math.random() * availableIndices.length)];
  recentFacts.push(randomIndex);
  
  if (recentFacts.length > 10) {
    recentFacts.shift();
  }
  
  return BODY_FACTS[randomIndex];
}