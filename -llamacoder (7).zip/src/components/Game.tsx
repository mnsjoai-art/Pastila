import { useRef, useEffect, useState, useCallback } from "react";
import { useGameLoop } from "../utils/useGameLoop";
import { LevelData } from "../App";
import { playSound, initAudio } from "../utils/soundEffects";
import { BloodCell, Bacteria, Virus, Platelet } from "../utils/bacteriaEffects";

interface GameProps {
  level: LevelData;
  levelNumber: number;
  onLevelComplete: (bouncesUsed: number) => void;
  onGameOver: () => void;
}

interface Ball {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  rotation: number;
  launched: boolean;
}

type InfectionType = "bacterial" | "viral" | "fungal";

const INFECTION_THEMES = {
  bacterial: {
    bgPrimary: "#050202",
    bgSecondary: "#0a0404",
    accent: "#ff3333",
    accentGlow: "#ff0000",
    particleColor: "rgba(255, 0, 0, 0.3)",
    name: "Bacteriană",
    plasma: "rgba(100, 20, 20, 0.08)"
  },
  viral: {
    bgPrimary: "#020502",
    bgSecondary: "#040a04",
    accent: "#33ff33",
    accentGlow: "#00ff00",
    particleColor: "rgba(0, 255, 0, 0.3)",
    name: "Virală",
    plasma: "rgba(20, 100, 20, 0.08)"
  },
  fungal: {
    bgPrimary: "#050302",
    bgSecondary: "#0a0804",
    accent: "#ff8800",
    accentGlow: "#ff6600",
    particleColor: "rgba(255, 136, 0, 0.3)",
    name: "Fungică",
    plasma: "rgba(100, 60, 20, 0.08)"
  }
};

export default function Game({ level, levelNumber, onLevelComplete, onGameOver }: GameProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [dimensions, setDimensions] = useState({ width: 300, height: 400 });
  const [bounces, setBounces] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [dragEnd, setDragEnd] = useState({ x: 0, y: 0 });
  const [gameState, setGameState] = useState<"aiming" | "playing" | "won" | "lost">("aiming");
  const [hasLaunched, setHasLaunched] = useState(false);
  const [infectionType, setInfectionType] = useState<InfectionType>("bacterial");
  
  const ballRef = useRef<Ball>({
    x: 0,
    y: 0,
    vx: 0,
    vy: 0,
    radius: 10,
    rotation: 0,
    launched: false
  });
  
  const bloodCellsRef = useRef<BloodCell[]>([]);
  const whiteCellsRef = useRef<BloodCell[]>([]);
  const bacteriaRef = useRef<Bacteria[]>([]);
  const virusesRef = useRef<Virus[]>([]);
  const plateletsRef = useRef<Platelet[]>([]);
  const scaleRef = useRef(1);

  useEffect(() => {
    const updateDimensions = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        const width = Math.floor(rect.width);
        const height = Math.floor(rect.height);
        setDimensions({ width, height });
        scaleRef.current = Math.min(width / 600, height / 500);
      }
    };
    
    updateDimensions();
    window.addEventListener("resize", updateDimensions);
    return () => window.removeEventListener("resize", updateDimensions);
  }, []);

  useEffect(() => {
    const types: InfectionType[] = ["bacterial", "viral", "fungal"];
    const randomType = types[Math.floor(Math.random() * types.length)];
    setInfectionType(randomType);

    bloodCellsRef.current = Array.from({ length: 40 }, () => new BloodCell(dimensions.width, dimensions.height, "red"));
    whiteCellsRef.current = Array.from({ length: 8 }, () => new BloodCell(dimensions.width, dimensions.height, "white"));
    bacteriaRef.current = Array.from({ length: 12 }, () => new Bacteria(dimensions.width, dimensions.height));
    virusesRef.current = Array.from({ length: 8 }, () => new Virus(dimensions.width, dimensions.height));
    plateletsRef.current = Array.from({ length: 15 }, () => new Platelet(dimensions.width, dimensions.height));
  }, [dimensions, levelNumber]);

  const resetBall = useCallback(() => {
    const scale = scaleRef.current;
    ballRef.current = {
      x: level.ballStart.x * scale,
      y: level.ballStart.y * scale,
      vx: 0,
      vy: 0,
      radius: Math.max(8, 12 * scale),
      rotation: 0,
      launched: false
    };
    setBounces(0);
    setHasLaunched(false);
    setGameState("aiming");
  }, [level]);

  useEffect(() => {
    resetBall();
  }, [level, resetBall]);

  const getEventPos = useCallback((e: React.TouchEvent | React.MouseEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    
    const rect = canvas.getBoundingClientRect();
    let clientX: number, clientY: number;
    
    if ('touches' in e) {
      if (e.touches.length === 0) return { x: 0, y: 0 };
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }
    
    return {
      x: clientX - rect.left,
      y: clientY - rect.top
    };
  }, []);

  const handleStart = useCallback((e: React.TouchEvent | React.MouseEvent) => {
    e.preventDefault();
    if (gameState !== "aiming") return;
    
    initAudio();
    const pos = getEventPos(e);
    setIsDragging(true);
    setDragStart(pos);
    setDragEnd(pos);
  }, [gameState, getEventPos]);

  const handleMove = useCallback((e: React.TouchEvent | React.MouseEvent) => {
    e.preventDefault();
    if (!isDragging || gameState !== "aiming") return;
    
    const pos = getEventPos(e);
    setDragEnd(pos);
  }, [isDragging, gameState, getEventPos]);

  const handleEnd = useCallback((e: React.TouchEvent | React.MouseEvent) => {
    e.preventDefault();
    if (!isDragging || gameState !== "aiming") return;
    
    setIsDragging(false);
    
    const dx = dragStart.x - dragEnd.x;
    const dy = dragStart.y - dragEnd.y;
    const power = Math.min(Math.sqrt(dx * dx + dy * dy) * 0.12, 12);
    
    if (power > 1) {
      const angle = Math.atan2(dy, dx);
      ballRef.current.vx = Math.cos(angle) * power;
      ballRef.current.vy = Math.sin(angle) * power;
      ballRef.current.launched = true;
      setHasLaunched(true);
      setGameState("playing");
      playSound.shoot();
    }
  }, [isDragging, gameState, dragStart, dragEnd]);

  const update = useCallback(() => {
    const ball = ballRef.current;
    const canvas = canvasRef.current;
    if (!canvas) return;

    bloodCellsRef.current.forEach(b => b.update());
    whiteCellsRef.current.forEach(b => b.update());
    bacteriaRef.current.forEach(b => b.update());
    virusesRef.current.forEach(v => v.update());
    plateletsRef.current.forEach(p => p.update());

    if (gameState !== "playing") return;

    ball.x += ball.vx;
    ball.y += ball.vy;
    ball.rotation += ball.vx * 0.05;

    if (ball.x - ball.radius < 0) {
      ball.x = ball.radius;
      ball.vx *= -0.95;
      setBounces(b => { const n = b + 1; if (n > level.maxBounces) setGameState("lost"); return n; });
      playSound.bounce();
    }
    if (ball.x + ball.radius > dimensions.width) {
      ball.x = dimensions.width - ball.radius;
      ball.vx *= -0.95;
      setBounces(b => { const n = b + 1; if (n > level.maxBounces) setGameState("lost"); return n; });
      playSound.bounce();
    }
    if (ball.y - ball.radius < 0) {
      ball.y = ball.radius;
      ball.vy *= -0.95;
      setBounces(b => { const n = b + 1; if (n > level.maxBounces) setGameState("lost"); return n; });
      playSound.bounce();
    }
    if (ball.y + ball.radius > dimensions.height) {
      ball.y = dimensions.height - ball.radius;
      ball.vy *= -0.95;
      setBounces(b => { const n = b + 1; if (n > level.maxBounces) setGameState("lost"); return n; });
      playSound.bounce();
    }

    const scale = scaleRef.current;
    level.obstacles.forEach(obs => {
      if (obs.type === "teleporter") return;
      
      const obsX = obs.x * scale;
      const obsY = obs.y * scale;
      const obsW = obs.width * scale;
      const obsH = obs.height * scale;
      
      if (
        ball.x + ball.radius > obsX &&
        ball.x - ball.radius < obsX + obsW &&
        ball.y + ball.radius > obsY &&
        ball.y - ball.radius < obsY + obsH
      ) {
        const overlapLeft = (ball.x + ball.radius) - obsX;
        const overlapRight = (obsX + obsW) - (ball.x - ball.radius);
        const overlapTop = (ball.y + ball.radius) - obsY;
        const overlapBottom = (obsY + obsH) - (ball.y - ball.radius);
        
        const minOverlap = Math.min(overlapLeft, overlapRight, overlapTop, overlapBottom);
        
        if (minOverlap === overlapLeft) {
          ball.x = obsX - ball.radius;
          ball.vx = -Math.abs(ball.vx);
        } else if (minOverlap === overlapRight) {
          ball.x = obsX + obsW + ball.radius;
          ball.vx = Math.abs(ball.vx);
        } else if (minOverlap === overlapTop) {
          ball.y = obsY - ball.radius;
          ball.vy = -Math.abs(ball.vy);
        } else {
          ball.y = obsY + obsH + ball.radius;
          ball.vy = Math.abs(ball.vy);
        }
        
        if (obs.type === "bouncy") {
          ball.vx *= 1.2;
          ball.vy *= 1.2;
          playSound.bouncyHit();
        } else {
          playSound.bounce();
        }
        
        setBounces(b => { const n = b + 1; if (n > level.maxBounces) setGameState("lost"); return n; });
      }
    });

    const portalX = level.portal.x * scale;
    const portalY = level.portal.y * scale;
    const portalDist = Math.sqrt(Math.pow(ball.x - portalX, 2) + Math.pow(ball.y - portalY, 2));
    if (portalDist < ball.radius + 20 * scale) {
      setGameState("won");
      playSound.levelComplete();
    }
  }, [gameState, dimensions, level]);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const scale = scaleRef.current;
    const theme = INFECTION_THEMES[infectionType];

    // Dark faded background
    ctx.fillStyle = theme.bgPrimary;
    ctx.fillRect(0, 0, dimensions.width, dimensions.height);

    // Subtle plasma gradient
    const plasmaGradient = ctx.createRadialGradient(
      dimensions.width / 2, dimensions.height / 2, 0,
      dimensions.width / 2, dimensions.height / 2, dimensions.width * 0.9
    );
    plasmaGradient.addColorStop(0, theme.bgSecondary);
    plasmaGradient.addColorStop(0.5, theme.bgPrimary);
    plasmaGradient.addColorStop(1, "#000000");
    
    ctx.fillStyle = plasmaGradient;
    ctx.fillRect(0, 0, dimensions.width, dimensions.height);

    // Very subtle plasma particles
    ctx.fillStyle = theme.plasma;
    for (let i = 0; i < 30; i++) {
      const x = Math.random() * dimensions.width;
      const y = Math.random() * dimensions.height;
      const size = Math.random() * 20 + 5;
      ctx.beginPath();
      ctx.arc(x, y, size, 0, Math.PI * 2);
      ctx.fill();
    }

    // Draw blood components (faded)
    ctx.globalAlpha = 0.4;
    plateletsRef.current.forEach(p => p.draw(ctx));
    bloodCellsRef.current.forEach(b => b.draw(ctx));
    whiteCellsRef.current.forEach(b => b.draw(ctx));
    ctx.globalAlpha = 1;

    // Draw neon infections
    bacteriaRef.current.forEach(b => {
      ctx.save();
      ctx.shadowColor = theme.accentGlow;
      ctx.shadowBlur = 15;
      b.draw(ctx);
      ctx.restore();
    });
    
    virusesRef.current.forEach(v => {
      ctx.save();
      ctx.shadowColor = theme.accentGlow;
      ctx.shadowBlur = 15;
      v.draw(ctx);
      ctx.restore();
    });

    // Draw obstacles
    level.obstacles.forEach(obs => {
      if (obs.type === "teleporter") return;
      
      const x = obs.x * scale;
      const y = obs.y * scale;
      const w = obs.width * scale;
      const h = obs.height * scale;
      
      ctx.save();
      ctx.translate(x + w/2, y + h/2);
      ctx.rotate((obs.angle || 0) * Math.PI / 180);
      
      if (obs.type === "solid") {
        ctx.fillStyle = "rgba(60, 60, 70, 0.6)";
        ctx.strokeStyle = "rgba(100, 100, 110, 0.4)";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.roundRect(-w/2, -h/2, w, h, 4 * scale);
        ctx.fill();
        ctx.stroke();
      } else if (obs.type === "bouncy") {
        // Neon bouncy obstacle
        ctx.shadowColor = theme.accentGlow;
        ctx.shadowBlur = 20;
        ctx.fillStyle = theme.accent;
        ctx.beginPath();
        ctx.roundRect(-w/2, -h/2, w, h, 6 * scale);
        ctx.fill();
        
        ctx.shadowBlur = 0;
        ctx.fillStyle = "rgba(255, 255, 255, 0.2)";
        ctx.beginPath();
        ctx.roundRect(-w/2 + 2*scale, -h/2 + 2*scale, w - 4*scale, h/3, 4 * scale);
        ctx.fill();
      }
      
      ctx.restore();
    });

    // Draw portal with neon glow
    const portalX = level.portal.x * scale;
    const portalY = level.portal.y * scale;
    const portalPulse = Math.sin(Date.now() / 150) * 0.3 + 1;
    
    // Outer glow
    ctx.shadowColor = theme.accentGlow;
    ctx.shadowBlur = 30 * portalPulse;
    ctx.fillStyle = `${theme.accent}60`;
    ctx.beginPath();
    ctx.arc(portalX, portalY, 35 * scale * portalPulse, 0, Math.PI * 2);
    ctx.fill();
    
    // Inner ring
    ctx.shadowBlur = 20;
    ctx.fillStyle = theme.accent;
    ctx.beginPath();
    ctx.arc(portalX, portalY, 22 * scale, 0, Math.PI * 2);
    ctx.fill();
    
    // Core
    ctx.shadowBlur = 10;
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.arc(portalX, portalY, 10 * scale, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.shadowBlur = 0;

    // Draw pill with neon glow
    const ball = ballRef.current;
    ctx.save();
    ctx.translate(ball.x, ball.y);
    ctx.rotate(ball.rotation);
    
    // Neon glow effect
    ctx.shadowColor = "#ff0066";
    ctx.shadowBlur = 25;
    
    // Pill body - white half
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.ellipse(0, 0, ball.radius * 1.5, ball.radius, 0, 0, Math.PI);
    ctx.fill();
    
    // Pill body - red half
    ctx.fillStyle = "#ff0044";
    ctx.beginPath();
    ctx.ellipse(0, 0, ball.radius * 1.5, ball.radius, 0, Math.PI, Math.PI * 2);
    ctx.fill();
    
    // Stronger glow on edges
    ctx.shadowBlur = 15;
    ctx.strokeStyle = "#ff0066";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.ellipse(0, 0, ball.radius * 1.5, ball.radius, 0, 0, Math.PI * 2);
    ctx.stroke();
    
    // Division line
    ctx.strokeStyle = "rgba(255, 255, 255, 0.5)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-ball.radius * 1.5, 0);
    ctx.lineTo(ball.radius * 1.5, 0);
    ctx.stroke();
    
    // Highlight on white part
    ctx.shadowBlur = 0;
    ctx.fillStyle = "rgba(255, 255, 255, 0.6)";
    ctx.beginPath();
    ctx.ellipse(-ball.radius * 0.4, -ball.radius * 0.3, ball.radius * 0.4, ball.radius * 0.2, -0.3, 0, Math.PI * 2);
    ctx.fill();
    
    // Highlight on red part
    ctx.fillStyle = "rgba(255, 100, 150, 0.4)";
    ctx.beginPath();
    ctx.ellipse(-ball.radius * 0.3, -ball.radius * 0.35, ball.radius * 0.35, ball.radius * 0.15, -0.3, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.restore();

    // Draw aiming line with neon effect
    if (isDragging && gameState === "aiming") {
      const dx = dragStart.x - dragEnd.x;
      const dy = dragStart.y - dragEnd.y;
      const power = Math.min(Math.sqrt(dx * dx + dy * dy) * 0.12, 12);
      
      if (power > 1) {
        const angle = Math.atan2(dy, dx);
        
        ctx.shadowColor = "#ff0066";
        ctx.shadowBlur = 10;
        ctx.strokeStyle = "rgba(255, 0, 102, 0.8)";
        ctx.lineWidth = 3;
        ctx.setLineDash([6, 6]);
        ctx.beginPath();
        ctx.moveTo(ball.x, ball.y);
        ctx.lineTo(ball.x + Math.cos(angle) * power * 15, ball.y + Math.sin(angle) * power * 15);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.shadowBlur = 0;
      }
    }
  }, [isDragging, dragStart, dragEnd, gameState, dimensions, level, hasLaunched, infectionType]);

  useGameLoop(() => {
    update();
    draw();
  });

  useEffect(() => {
    if (gameState === "won") {
      const timer = setTimeout(() => onLevelComplete(bounces), 500);
      return () => clearTimeout(timer);
    } else if (gameState === "lost") {
      playSound.gameOver();
      const timer = setTimeout(() => onGameOver(), 500);
      return () => clearTimeout(timer);
    }
  }, [gameState, bounces, onLevelComplete, onGameOver]);

  const theme = INFECTION_THEMES[infectionType];

  return (
    <div ref={containerRef} className="flex-1 flex flex-col relative">
      <canvas
        ref={canvasRef}
        width={dimensions.width}
        height={dimensions.height}
        className="flex-1 rounded-xl sm:rounded-2xl border-2 shadow-2xl touch-none"
        style={{ 
          borderColor: theme.accent, 
          boxShadow: `0 0 30px ${theme.accentGlow}40, inset 0 0 60px rgba(0,0,0,0.8)` 
        }}
        onTouchStart={handleStart}
        onTouchMove={handleMove}
        onTouchEnd={handleEnd}
        onMouseDown={handleStart}
        onMouseMove={handleMove}
        onMouseUp={handleEnd}
        onMouseLeave={handleEnd}
      />
      
      <div 
        className="absolute top-2 left-2 px-2 sm:px-4 py-1 sm:py-2 rounded-lg sm:rounded-xl border backdrop-blur-sm" 
        style={{ 
          backgroundColor: "rgba(0, 0, 0, 0.7)", 
          borderColor: theme.accent,
          boxShadow: `0 0 10px ${theme.accentGlow}30`
        }}
      >
        <p className="text-xs" style={{ color: theme.accent }}>Nivel {levelNumber}</p>
        <p className="text-white font-bold text-sm sm:text-base">{level.name}</p>
      </div>
      
      <div 
        className="absolute top-2 right-2 px-2 sm:px-4 py-1 sm:py-2 rounded-lg sm:rounded-xl border backdrop-blur-sm" 
        style={{ 
          backgroundColor: "rgba(0, 0, 0, 0.7)", 
          borderColor: theme.accent,
          boxShadow: `0 0 10px ${theme.accentGlow}30`
        }}
      >
        <p className="text-xs" style={{ color: theme.accent }}>Ricoșaje</p>
        <p 
          className="font-bold text-sm sm:text-base" 
          style={{ 
            color: bounces > level.maxBounces * 0.8 ? "#ff3333" : "#ffffff",
            textShadow: bounces > level.maxBounces * 0.8 ? "0 0 10px #ff0000" : "none"
          }}
        >
          {bounces}/{level.maxBounces}
        </p>
      </div>

      <div 
        className="absolute bottom-2 left-2 px-2 py-1 rounded-lg border backdrop-blur-sm" 
        style={{ 
          backgroundColor: "rgba(0, 0, 0, 0.7)", 
          borderColor: theme.accent,
          boxShadow: `0 0 10px ${theme.accentGlow}30`
        }}
      >
        <p className="text-xs" style={{ color: theme.accent }}>Infecție {theme.name}</p>
      </div>
      
      {!hasLaunched && gameState === "aiming" && (
        <div 
          className="absolute bottom-4 left-1/2 -translate-x-1/2 px-3 py-2 rounded-lg sm:rounded-xl border backdrop-blur-sm" 
          style={{ 
            backgroundColor: "rgba(0, 0, 0, 0.7)", 
            borderColor: theme.accent,
            boxShadow: `0 0 10px ${theme.accentGlow}30`
          }}
        >
          <p className="text-xs sm:text-sm" style={{ color: theme.accent }}>Atinge și trage pentru a ținti</p>
        </div>
      )}
    </div>
  );
}