import { useRef, useState, useEffect, useCallback } from "react";
import * as THREE from "three";
import { LevelData, Obstacle } from "../App";

interface Game3DProps {
  level: LevelData;
  levelNumber: number;
  totalLevels: number;
  onLevelComplete: (bouncesUsed: number, score: number) => void;
  onGameOver: () => void;
}

const GAME_WIDTH = 12;
const GAME_HEIGHT = 10;
const BALL_RADIUS = 0.3;
const BALL_SPEED = 0.15;
const PORTAL_RADIUS = 0.8;

export default function Game3D({ level, levelNumber, totalLevels, onLevelComplete, onGameOver }: Game3DProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const ballRef = useRef<THREE.Mesh | null>(null);
  const ballVelocityRef = useRef({ dx: 0, dy: 0 });
  const isMovingRef = useRef(false);
  const bouncesRef = useRef(0);
  const obstaclesRef = useRef<THREE.Mesh[]>([]);
  const portalRef = useRef<THREE.Mesh | null>(null);
  const trailRef = useRef<THREE.Points | null>(null);
  const trailPositionsRef = useRef<Float32Array>(new Float32Array(300));
  const trailIndexRef = useRef(0);
  
  const [isAiming, setIsAiming] = useState(true);
  const [bounces, setBounces] = useState(0);
  const [levelComplete, setLevelComplete] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  
  const aimStartRef = useRef<{ x: number; y: number } | null>(null);
  const aimLineRef = useRef<THREE.Line | null>(null);
  const trajectoryLineRef = useRef<THREE.Line | null>(null);

  // Initialize Three.js scene
  useEffect(() => {
    if (!containerRef.current) return;

    // Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0f172a);
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(60, containerRef.current.clientWidth / containerRef.current.clientHeight, 0.1, 1000);
    camera.position.set(0, 0, 15);
    camera.lookAt(0, 0, 0);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lights
    const ambientLight = new THREE.AmbientLight(0x404040, 0.5);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(5, 10, 7);
    directionalLight.castShadow = true;
    directionalLight.shadow.mapSize.width = 2048;
    directionalLight.shadow.mapSize.height = 2048;
    scene.add(directionalLight);

    const pointLight = new THREE.PointLight(0xfbbf24, 1, 20);
    pointLight.position.set(0, 5, 5);
    scene.add(pointLight);

    // Walls (bouncy borders)
    const wallMaterial = new THREE.MeshStandardMaterial({ 
      color: 0x10b981,
      emissive: 0x10b981,
      emissiveIntensity: 0.3,
      metalness: 0.5,
      roughness: 0.3
    });

    // Top wall
    const topWall = new THREE.Mesh(
      new THREE.BoxGeometry(GAME_WIDTH + 0.4, 0.3, 0.5),
      wallMaterial
    );
    topWall.position.set(0, GAME_HEIGHT / 2 + 0.15, 0);
    scene.add(topWall);

    // Bottom wall
    const bottomWall = new THREE.Mesh(
      new THREE.BoxGeometry(GAME_WIDTH + 0.4, 0.3, 0.5),
      wallMaterial
    );
    bottomWall.position.set(0, -GAME_HEIGHT / 2 - 0.15, 0);
    scene.add(bottomWall);

    // Left wall
    const leftWall = new THREE.Mesh(
      new THREE.BoxGeometry(0.3, GAME_HEIGHT + 0.4, 0.5),
      wallMaterial
    );
    leftWall.position.set(-GAME_WIDTH / 2 - 0.15, 0, 0);
    scene.add(leftWall);

    // Right wall
    const rightWall = new THREE.Mesh(
      new THREE.BoxGeometry(0.3, GAME_HEIGHT + 0.4, 0.5),
      wallMaterial
    );
    rightWall.position.set(GAME_WIDTH / 2 + 0.15, 0, 0);
    scene.add(rightWall);

    // Grid floor
    const gridHelper = new THREE.GridHelper(20, 20, 0x1e293b, 0x1e293b);
    gridHelper.rotation.x = Math.PI / 2;
    gridHelper.position.z = -0.5;
    scene.add(gridHelper);

    // Ball
    const ballGeometry = new THREE.SphereGeometry(BALL_RADIUS, 32, 32);
    const ballMaterial = new THREE.MeshStandardMaterial({
      color: 0xfbbf24,
      emissive: 0xfbbf24,
      emissiveIntensity: 0.5,
      metalness: 0.8,
      roughness: 0.2
    });
    const ball = new THREE.Mesh(ballGeometry, ballMaterial);
    ball.castShadow = true;
    ball.position.set(
      (level.ballStart.x / 600) * GAME_WIDTH - GAME_WIDTH / 2,
      (level.ballStart.y / 500) * GAME_HEIGHT - GAME_HEIGHT / 2,
      0
    );
    scene.add(ball);
    ballRef.current = ball;

    // Trail particles
    const trailGeometry = new THREE.BufferGeometry();
    trailGeometry.setAttribute('position', new THREE.BufferAttribute(trailPositionsRef.current, 3));
    const trailMaterial = new THREE.PointsMaterial({
      color: 0xfbbf24,
      size: 0.1,
      transparent: true,
      opacity: 0.6
    });
    const trail = new THREE.Points(trailGeometry, trailMaterial);
    scene.add(trail);
    trailRef.current = trail;

    // Aim line
    const aimGeometry = new THREE.BufferGeometry();
    const aimMaterial = new THREE.LineBasicMaterial({ color: 0xfbbf24, linewidth: 2 });
    const aimLine = new THREE.Line(aimGeometry, aimMaterial);
    aimLine.visible = false;
    scene.add(aimLine);
    aimLineRef.current = aimLine;

    // Trajectory preview line
    const trajectoryGeometry = new THREE.BufferGeometry();
    const trajectoryMaterial = new THREE.LineDashedMaterial({ 
      color: 0xfbbf24, 
      dashSize: 0.3, 
      gapSize: 0.2,
      linewidth: 2 
    });
    const trajectoryLine = new THREE.Line(trajectoryGeometry, trajectoryMaterial);
    trajectoryLine.visible = false;
    scene.add(trajectoryLine);
    trajectoryLineRef.current = trajectoryLine;

    // Animation loop
    const animate = () => {
      requestAnimationFrame(animate);
      renderer.render(scene, camera);
    };
    animate();

    // Handle resize
    const handleResize = () => {
      if (!containerRef.current) return;
      camera.aspect = containerRef.current.clientWidth / containerRef.current.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    };
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      if (containerRef.current && renderer.domElement) {
        containerRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  // Create obstacles when level changes
  useEffect(() => {
    if (!sceneRef.current) return;

    // Remove old obstacles
    obstaclesRef.current.forEach(mesh => {
      sceneRef.current?.remove(mesh);
    });
    obstaclesRef.current = [];

    // Remove old portal
    if (portalRef.current) {
      sceneRef.current.remove(portalRef.current);
      portalRef.current = null;
    }

    // Create new obstacles
    level.obstacles.forEach(obs => {
      const worldX = (obs.x / 600) * GAME_WIDTH - GAME_WIDTH / 2 + (obs.width / 600) * GAME_WIDTH / 2;
      const worldY = (obs.y / 500) * GAME_HEIGHT - GAME_HEIGHT / 2 + (obs.height / 500) * GAME_HEIGHT / 2;
      const worldWidth = (obs.width / 600) * GAME_WIDTH;
      const worldHeight = (obs.height / 500) * GAME_HEIGHT;

      let color = 0x6366f1;
      if (obs.type === "bouncy") color = 0xf97316;
      if (obs.type === "sticky") color = 0xa855f7;

      const geometry = new THREE.BoxGeometry(worldWidth, worldHeight, 0.3);
      const material = new THREE.MeshStandardMaterial({
        color,
        emissive: color,
        emissiveIntensity: 0.3,
        metalness: 0.6,
        roughness: 0.3
      });
      const mesh = new THREE.Mesh(geometry, material);
      mesh.position.set(worldX, worldY, 0);
      mesh.rotation.z = (obs.angle || 0) * Math.PI / 180;
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      mesh.userData = { ...obs, worldX, worldY, worldWidth, worldHeight };
      sceneRef.current.add(mesh);
      obstaclesRef.current.push(mesh);
    });

    // Create portal
    const portalX = (level.portal.x / 600) * GAME_WIDTH - GAME_WIDTH / 2;
    const portalY = (level.portal.y / 500) * GAME_HEIGHT - GAME_HEIGHT / 2;
    
    const portalGeometry = new THREE.TorusGeometry(PORTAL_RADIUS, 0.15, 16, 32);
    const portalMaterial = new THREE.MeshStandardMaterial({
      color: 0xfbbf24,
      emissive: 0xfbbf24,
      emissiveIntensity: 0.8,
      metalness: 0.9,
      roughness: 0.1
    });
    const portalMesh = new THREE.Mesh(portalGeometry, portalMaterial);
    portalMesh.position.set(portalX, portalY, 0);
    sceneRef.current.add(portalMesh);
    portalRef.current = portalMesh;

    // Reset ball position
    if (ballRef.current) {
      const ballX = (level.ballStart.x / 600) * GAME_WIDTH - GAME_WIDTH / 2;
      const ballY = (level.ballStart.y / 500) * GAME_HEIGHT - GAME_HEIGHT / 2;
      ballRef.current.position.set(ballX, ballY, 0);
    }

    // Reset state
    setIsAiming(true);
    setBounces(0);
    setLevelComplete(false);
    setGameOver(false);
    bouncesRef.current = 0;
    isMovingRef.current = false;
    ballVelocityRef.current = { dx: 0, dy: 0 };
    trailIndexRef.current = 0;

  }, [level]);

  // Convert screen coords to world coords
  const screenToWorld = useCallback((clientX: number, clientY: number) => {
    if (!containerRef.current || !cameraRef.current) return null;
    
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((clientY - rect.top) / rect.height) * 2 + 1;
    
    const vector = new THREE.Vector3(x, y, 0);
    vector.unproject(cameraRef.current);
    
    const dir = vector.sub(cameraRef.current.position).normalize();
    const distance = -cameraRef.current.position.z / dir.z;
    const pos = cameraRef.current.position.clone().add(dir.multiplyScalar(distance));
    
    return { x: pos.x, y: pos.y };
  }, []);

  // Calculate trajectory
  const calculateTrajectory = useCallback((startX: number, startY: number, dx: number, dy: number): number[] => {
    const points: number[] = [];
    let x = startX;
    let y = startY;
    let vx = dx;
    let vy = dy;
    
    for (let i = 0; i < 100; i++) {
      points.push(x, y, 0);
      
      // Wall bounces
      if (x - BALL_RADIUS < -GAME_WIDTH / 2) {
        x = -GAME_WIDTH / 2 + BALL_RADIUS;
        vx = Math.abs(vx);
      }
      if (x + BALL_RADIUS > GAME_WIDTH / 2) {
        x = GAME_WIDTH / 2 - BALL_RADIUS;
        vx = -Math.abs(vx);
      }
      if (y - BALL_RADIUS < -GAME_HEIGHT / 2) {
        y = -GAME_HEIGHT / 2 + BALL_RADIUS;
        vy = Math.abs(vy);
      }
      if (y + BALL_RADIUS > GAME_HEIGHT / 2) {
        y = GAME_HEIGHT / 2 - BALL_RADIUS;
        vy = -Math.abs(vy);
      }
      
      // Portal check
      const portalX = (level.portal.x / 600) * GAME_WIDTH - GAME_WIDTH / 2;
      const portalY = (level.portal.y / 500) * GAME_HEIGHT - GAME_HEIGHT / 2;
      const distToPortal = Math.sqrt((x - portalX) ** 2 + (y - portalY) ** 2);
      if (distToPortal < PORTAL_RADIUS) break;
      
      x += vx;
      y += vy;
    }
    
    return points;
  }, [level]);

  // Mouse handlers
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (!isAiming) return;
    const worldPos = screenToWorld(e.clientX, e.clientY);
    if (worldPos) {
      aimStartRef.current = worldPos;
    }
  }, [isAiming, screenToWorld]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!aimStartRef.current || !isAiming || !ballRef.current) return;
    
    const worldPos = screenToWorld(e.clientX, e.clientY);
    if (!worldPos) return;
    
    const dx = aimStartRef.current.x - worldPos.x;
    const dy = aimStartRef.current.y - worldPos.y;
    const magnitude = Math.sqrt(dx * dx + dy * dy);
    
    if (magnitude > 0.5 && aimLineRef.current) {
      const ballPos = ballRef.current.position;
      const linePoints = [
        ballPos.x, ballPos.y, 0,
        ballPos.x + dx * 0.5, ballPos.y + dy * 0.5, 0
      ];
      aimLineRef.current.geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(linePoints), 3));
      aimLineRef.current.visible = true;
      
      // Calculate trajectory preview
      const normalizedDx = (dx / magnitude) * BALL_SPEED;
      const normalizedDy = (dy / magnitude) * BALL_SPEED;
      const trajectoryPoints = calculateTrajectory(ballPos.x, ballPos.y, normalizedDx, normalizedDy);
      
      if (trajectoryLineRef.current && trajectoryPoints.length > 3) {
        trajectoryLineRef.current.geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(trajectoryPoints), 3));
        trajectoryLineRef.current.computeLineDistances();
        trajectoryLineRef.current.visible = true;
      }
    }
  }, [isAiming, screenToWorld, calculateTrajectory]);

  const handleMouseUp = useCallback((e: React.MouseEvent) => {
    if (!aimStartRef.current || !isAiming) return;
    
    const worldPos = screenToWorld(e.clientX, e.clientY);
    if (!worldPos) return;
    
    const dx = aimStartRef.current.x - worldPos.x;
    const dy = aimStartRef.current.y - worldPos.y;
    const magnitude = Math.sqrt(dx * dx + dy * dy);
    
    if (magnitude > 0.5) {
      ballVelocityRef.current = {
        dx: (dx / magnitude) * BALL_SPEED,
        dy: (dy / magnitude) * BALL_SPEED
      };
      isMovingRef.current = true;
      setIsAiming(false);
      
      if (aimLineRef.current) aimLineRef.current.visible = false;
      if (trajectoryLineRef.current) trajectoryLineRef.current.visible = false;
    }
    
    aimStartRef.current = null;
  }, [isAiming, screenToWorld]);

  // Game loop
  useEffect(() => {
    if (!sceneRef.current || !ballRef.current) return;
    
    let animationId: number;
    
    const updateGame = () => {
      animationId = requestAnimationFrame(updateGame);
      
      if (!isMovingRef.current || !ballRef.current) return;
      
      const ball = ballRef.current;
      let { dx, dy } = ballVelocityRef.current;
      
      // Update trail
      const positions = trailRef.current?.geometry.attributes.position.array as Float32Array;
      if (positions) {
        const idx = trailIndexRef.current * 3;
        positions[idx] = ball.position.x;
        positions[idx + 1] = ball.position.y;
        positions[idx + 2] = 0;
        trailIndexRef.current = (trailIndexRef.current + 1) % 100;
        trailRef.current!.geometry.attributes.position.needsUpdate = true;
      }
      
      // Move ball
      ball.position.x += dx;
      ball.position.y += dy;
      
      // Wall bounces
      if (ball.position.x - BALL_RADIUS < -GAME_WIDTH / 2) {
        ball.position.x = -GAME_WIDTH / 2 + BALL_RADIUS;
        ballVelocityRef.current.dx = Math.abs(dx);
        bouncesRef.current++;
        setBounces(bouncesRef.current);
      }
      if (ball.position.x + BALL_RADIUS > GAME_WIDTH / 2) {
        ball.position.x = GAME_WIDTH / 2 - BALL_RADIUS;
        ballVelocityRef.current.dx = -Math.abs(dx);
        bouncesRef.current++;
        setBounces(bouncesRef.current);
      }
      if (ball.position.y - BALL_RADIUS < -GAME_HEIGHT / 2) {
        ball.position.y = -GAME_HEIGHT / 2 + BALL_RADIUS;
        ballVelocityRef.current.dy = Math.abs(dy);
        bouncesRef.current++;
        setBounces(bouncesRef.current);
      }
      if (ball.position.y + BALL_RADIUS > GAME_HEIGHT / 2) {
        ball.position.y = GAME_HEIGHT / 2 - BALL_RADIUS;
        ballVelocityRef.current.dy = -Math.abs(dy);
        bouncesRef.current++;
        setBounces(bouncesRef.current);
      }
      
      // Obstacle collisions
      obstaclesRef.current.forEach(mesh => {
        const obs = mesh.userData;
        const obsX = obs.worldX;
        const obsY = obs.worldY;
        const obsW = obs.worldWidth / 2;
        const obsH = obs.worldHeight / 2;
        
        // Simple AABB collision (ignoring rotation for simplicity)
        if (
          ball.position.x + BALL_RADIUS > obsX - obsW &&
          ball.position.x - BALL_RADIUS < obsX + obsW &&
          ball.position.y + BALL_RADIUS > obsY - obsH &&
          ball.position.y - BALL_RADIUS < obsY + obsH
        ) {
          // Determine collision side
          const overlapLeft = (ball.position.x + BALL_RADIUS) - (obsX - obsW);
          const overlapRight = (obsX + obsW) - (ball.position.x - BALL_RADIUS);
          const overlapTop = (ball.position.y + BALL_RADIUS) - (obsY - obsH);
          const overlapBottom = (obsY + obsH) - (ball.position.y - BALL_RADIUS);
          
          const minOverlap = Math.min(overlapLeft, overlapRight, overlapTop, overlapBottom);
          
          if (minOverlap === overlapLeft || minOverlap === overlapRight) {
            ballVelocityRef.current.dx = -ballVelocityRef.current.dx;
            ball.position.x += minOverlap === overlapLeft ? -overlapLeft : overlapRight;
          } else {
            ballVelocityRef.current.dy = -ballVelocityRef.current.dy;
            ball.position.y += minOverlap === overlapTop ? -overlapTop : overlapBottom;
          }
          
          bouncesRef.current++;
          setBounces(bouncesRef.current);
        }
      });
      
      // Check portal
      const portalX = (level.portal.x / 600) * GAME_WIDTH - GAME_WIDTH / 2;
      const portalY = (level.portal.y / 500) * GAME_HEIGHT - GAME_HEIGHT / 2;
      const distToPortal = Math.sqrt(
        (ball.position.x - portalX) ** 2 + 
        (ball.position.y - portalY) ** 2
      );
      
      if (distToPortal < PORTAL_RADIUS + BALL_RADIUS) {
        isMovingRef.current = false;
        setLevelComplete(true);
        const score = Math.max(100, (level.maxBounces - bouncesRef.current) * 50 + 100);
        setTimeout(() => onLevelComplete(bouncesRef.current, score), 500);
        return;
      }
      
      // Check max bounces
      if (bouncesRef.current >= level.maxBounces) {
        isMovingRef.current = false;
        setGameOver(true);
        setTimeout(() => onGameOver(), 500);
      }
    };
    
    animationId = requestAnimationFrame(updateGame);
    
    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [level, onLevelComplete, onGameOver]);

  // Rotate portal
  useEffect(() => {
    if (!portalRef.current) return;
    
    const animate = () => {
      if (portalRef.current) {
        portalRef.current.rotation.z += 0.02;
      }
      requestAnimationFrame(animate);
    };
    animate();
  }, []);

  return (
    <div className="bg-slate-800 rounded-3xl p-6 border-2 border-violet-500 shadow-2xl">
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center gap-3">
          <span className="bg-violet-500 text-white px-4 py-2 rounded-full font-bold text-lg">
            Level {levelNumber}/{totalLevels}
          </span>
          <span className="text-slate-400 text-sm">{level.name}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-slate-400">Bounces:</span>
          <span className={`font-bold text-lg ${bounces > level.maxBounces * 0.7 ? 'text-red-400' : 'text-emerald-400'}`}>
            {bounces}/{level.maxBounces}
          </span>
        </div>
      </div>

      <div 
        ref={containerRef}
        className="w-full h-[500px] rounded-xl cursor-crosshair overflow-hidden"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={() => {
          if (aimLineRef.current) aimLineRef.current.visible = false;
          if (trajectoryLineRef.current) trajectoryLineRef.current.visible = false;
        }}
      />

      {isAiming && (
        <div className="mt-4 text-center">
          <p className="text-amber-400 text-lg font-semibold">
            🎯 Click and drag to aim, release to shoot!
          </p>
        </div>
      )}

      {levelComplete && (
        <div className="mt-4 text-center">
          <p className="text-emerald-400 text-xl font-bold">
            ✨ Level Complete! ✨
          </p>
        </div>
      )}

      {gameOver && (
        <div className="mt-4 text-center">
          <p className="text-red-400 text-xl font-bold">
            Out of bounces!
          </p>
        </div>
      )}

      <div className="flex justify-center gap-6 mt-4 text-sm">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded bg-indigo-500"></div>
          <span className="text-slate-400">Solid</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded border-2 border-emerald-500"></div>
          <span className="text-slate-400">Bouncy Wall</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full bg-amber-500"></div>
          <span className="text-slate-400">Goal</span>
        </div>
      </div>
    </div>
  );
}