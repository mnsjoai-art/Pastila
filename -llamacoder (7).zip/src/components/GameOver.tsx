import { Button } from "../components/ui/button";

interface GameOverProps {
  score: number;
  level: number;
  onRestart: () => void;
  highScore: number;
}

export default function GameOver({ score, level, onRestart, highScore }: GameOverProps) {
  const isNewHighScore = score > 0 && score >= highScore;

  return (
    <div className="flex-1 bg-emerald-900/80 rounded-2xl sm:rounded-3xl p-4 sm:p-8 border-2 border-red-500 shadow-2xl shadow-red-500/20 text-center flex flex-col justify-center">
      <div className="mb-4 sm:mb-6">
        <h1 className="text-3xl sm:text-4xl font-bold text-red-400 mb-1 sm:mb-2">💔 Tratament Eșuat</h1>
        <p className="text-emerald-300 text-sm sm:text-base">Infecția s-a răspândit...</p>
      </div>

      <div className="bg-emerald-950/50 rounded-xl sm:rounded-2xl p-4 sm:p-6 mb-4 sm:mb-6">
        <div className="grid grid-cols-2 gap-3 sm:gap-4">
          <div>
            <p className="text-emerald-400 text-xs sm:text-sm">Nivel Final</p>
            <p className="text-2xl sm:text-3xl font-bold text-white">{level}</p>
          </div>
          <div>
            <p className="text-emerald-400 text-xs sm:text-sm">Scor</p>
            <p className="text-2xl sm:text-3xl font-bold text-emerald-300">{score}</p>
          </div>
        </div>
      </div>

      {isNewHighScore && (
        <div className="bg-yellow-500/20 border border-yellow-500/50 rounded-lg sm:rounded-xl p-3 sm:p-4 mb-4 sm:mb-6">
          <p className="text-yellow-400 font-bold text-base sm:text-lg">🏆 Scor Nou Maxim!</p>
        </div>
      )}

      <div className="bg-emerald-950/50 rounded-lg sm:rounded-xl p-3 sm:p-4 mb-4 sm:mb-6">
        <p className="text-emerald-400 text-xs sm:text-sm">Scor Maxim</p>
        <p className="text-xl sm:text-2xl font-bold text-emerald-300">{highScore}</p>
      </div>

      <Button
        onClick={onRestart}
        className="bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-base sm:text-lg px-8 sm:px-10 py-4 sm:py-5 rounded-xl sm:rounded-2xl transition-all hover:scale-105 active:scale-95 shadow-lg shadow-emerald-500/30"
      >
        Începe Din Nou
      </Button>
    </div>
  );
}