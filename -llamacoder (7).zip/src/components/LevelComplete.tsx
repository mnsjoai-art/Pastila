import { Button } from "./ui/button";
import { ArrowRight, Star } from "lucide-react";
import { BodyFact } from "../App";

interface LevelCompleteProps {
  level: number;
  score: number;
  totalScore: number;
  fact: BodyFact;
  bouncesUsed: number;
  maxBounces: number;
  onNextLevel: () => void;
}

export default function LevelComplete({ 
  level, 
  score, 
  totalScore, 
  fact, 
  bouncesUsed, 
  maxBounces,
  onNextLevel 
}: LevelCompleteProps) {
  const efficiency = Math.max(0, Math.round((1 - bouncesUsed / maxBounces) * 100));
  const stars = efficiency >= 80 ? 3 : efficiency >= 50 ? 2 : 1;

  return (
    <div className="flex-1 bg-emerald-900/80 rounded-2xl sm:rounded-3xl p-4 sm:p-6 border-2 border-emerald-500 shadow-2xl shadow-emerald-500/20 flex flex-col">
      {/* Header */}
      <div className="text-center mb-3 sm:mb-6">
        <div className="inline-block bg-emerald-500 text-white px-3 py-1 rounded-full text-xs font-bold mb-2 uppercase tracking-wider">
          Level {level} Complete!
        </div>
        <h1 className="text-2xl sm:text-4xl font-bold text-emerald-400">
          🎉 Great Job!
        </h1>
        
        {/* Stars */}
        <div className="flex items-center justify-center gap-1 sm:gap-2 my-2 sm:my-4">
          {[1, 2, 3].map((i) => (
            <Star 
              key={i}
              className={`w-6 h-6 sm:w-10 sm:h-10 transition-all ${
                i <= stars 
                  ? 'text-amber-400 fill-amber-400 drop-shadow-lg' 
                  : 'text-slate-600'
              }`}
            />
          ))}
        </div>

        {/* Score Summary */}
        <div className="grid grid-cols-3 gap-2 sm:gap-3 mt-2 sm:mt-4">
          <div className="bg-emerald-950/50 rounded-lg sm:rounded-xl p-2 sm:p-3">
            <p className="text-emerald-400 text-xs">Level</p>
            <p className="text-lg sm:text-2xl font-bold text-white">{score}</p>
          </div>
          <div className="bg-emerald-950/50 rounded-lg sm:rounded-xl p-2 sm:p-3">
            <p className="text-emerald-400 text-xs">Efficiency</p>
            <p className="text-lg sm:text-2xl font-bold text-emerald-300">{efficiency}%</p>
          </div>
          <div className="bg-emerald-950/50 rounded-lg sm:rounded-xl p-2 sm:p-3">
            <p className="text-emerald-400 text-xs">Total</p>
            <p className="text-lg sm:text-2xl font-bold text-amber-400">{totalScore}</p>
          </div>
        </div>
      </div>

      {/* Fact Card */}
      <div className="flex-1 bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl sm:rounded-2xl p-3 sm:p-5 mb-3 sm:mb-6 border border-slate-600">
        <div className="flex items-start gap-2 sm:gap-4">
          <div className="text-3xl sm:text-5xl">{fact.icon}</div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full">
                {fact.category}
              </span>
            </div>
            <h3 className="text-base sm:text-xl font-bold text-white mb-1 sm:mb-2">
              {fact.title}
            </h3>
            <p className="text-slate-300 text-xs sm:text-base leading-relaxed">
              {fact.fact}
            </p>
          </div>
        </div>
      </div>

      {/* Badge */}
      <div className="text-center mb-3 sm:mb-6">
        <span className="inline-flex items-center gap-1 sm:gap-2 bg-amber-500/20 text-amber-400 px-3 sm:px-4 py-1 sm:py-2 rounded-full text-xs sm:text-sm font-medium">
          <span>💡</span>
          <span>Did You Know?</span>
        </span>
      </div>

      {/* Next Button */}
      <Button
        onClick={onNextLevel}
        className="w-full bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-base sm:text-xl py-4 sm:py-6 rounded-xl sm:rounded-2xl transition-all hover:scale-[1.02] active:scale-[0.98] shadow-lg shadow-emerald-500/30"
      >
        Next Level
        <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5 ml-2" />
      </Button>
    </div>
  );
}