import { Button } from "../components/ui/button";

interface StartScreenProps {
  onStart: () => void;
  highScore: number;
}

export default function StartScreen({ onStart, highScore }: StartScreenProps) {
  return (
    <div className="flex-1 bg-emerald-900/80 rounded-2xl sm:rounded-3xl p-4 sm:p-8 border-2 border-emerald-500 shadow-2xl shadow-emerald-500/20 text-center flex flex-col justify-center">
      <div className="mb-4 sm:mb-8">
        <h1 className="text-3xl sm:text-5xl font-bold text-emerald-400 mb-1 sm:mb-2">💊 Pill Bounce</h1>
        <p className="text-emerald-300 text-base sm:text-lg">Vindecă infecția!</p>
      </div>

      <div className="bg-emerald-950/50 rounded-xl sm:rounded-2xl p-3 sm:p-6 mb-4 sm:mb-8">
        <h2 className="text-lg sm:text-xl font-semibold text-emerald-300 mb-3 sm:mb-4">Cum se joacă</h2>
        <div className="text-left text-emerald-200 space-y-2 sm:space-y-3 text-sm sm:text-base">
          <div className="flex items-start gap-2 sm:gap-3">
            <span className="text-xl sm:text-2xl">🎯</span>
            <p><strong>Obiectiv:</strong> Lansează pastila pentru a atinge ținta roșie</p>
          </div>
          <div className="flex items-start gap-2 sm:gap-3">
            <span className="text-xl sm:text-2xl">👆</span>
            <p><strong>Controale:</strong> Atinge și trage pentru a ținti, eliberează pentru a lansa</p>
          </div>
          <div className="flex items-start gap-2 sm:gap-3">
            <span className="text-xl sm:text-2xl">🧱</span>
            <p><strong>Suprafețe:</strong> Ricoșează din pereți și platforme</p>
          </div>
          <div className="flex items-start gap-2 sm:gap-3">
            <span className="text-xl sm:text-2xl">⚡</span>
            <p><strong>Limită:</strong> Nu depăși numărul maxim de ricoșaje!</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 sm:gap-4 mb-4 sm:mb-8">
        <div className="bg-emerald-950/50 rounded-lg sm:rounded-xl p-2 sm:p-4">
          <p className="text-emerald-400 text-xs sm:text-sm">Niveluri</p>
          <p className="text-2xl sm:text-3xl font-bold text-white">∞</p>
        </div>
        <div className="bg-emerald-950/50 rounded-lg sm:rounded-xl p-2 sm:p-4">
          <p className="text-emerald-400 text-xs sm:text-sm">Scor Maxim</p>
          <p className="text-2xl sm:text-3xl font-bold text-emerald-300">{highScore}</p>
        </div>
      </div>

      <Button
        onClick={onStart}
        className="bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-lg sm:text-xl px-8 sm:px-12 py-4 sm:py-6 rounded-xl sm:rounded-2xl transition-all hover:scale-105 active:scale-95 shadow-lg shadow-emerald-500/30"
      >
        Începe Tratamentul
      </Button>

      <div className="mt-4 sm:mt-6 flex justify-center gap-3 sm:gap-4 text-xs text-emerald-500">
        <div className="flex items-center gap-1">
          <div className="w-2 h-2 sm:w-3 sm:h-3 rounded bg-emerald-500"></div>
          <span>Solid</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-2 h-2 sm:w-3 sm:h-3 rounded bg-green-500"></div>
          <span>Elastic</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-2 h-2 sm:w-3 sm:h-3 rounded bg-purple-500"></div>
          <span>Lipicios</span>
        </div>
      </div>
    </div>
  );
}