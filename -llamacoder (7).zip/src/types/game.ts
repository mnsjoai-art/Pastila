export interface Ball {
  x: number;
  y: number;
  dx: number;
  dy: number;
}

export interface Paddle {
  x: number;
  y: number;
}

export interface GameState {
  ball: Ball;
  paddle: Paddle;
  score: number;
  lives: number;
  bounces: number;
}