export class BackgroundParticle {
  x: number;
  y: number;
  size: number;
  speedX: number;
  speedY: number;
  opacity: number;
  pulseSpeed: number;
  pulseOffset: number;
  color: string;
  gameWidth: number;
  gameHeight: number;

  constructor(theme: { particleColor: string }, gameWidth: number, gameHeight: number) {
    this.gameWidth = gameWidth;
    this.gameHeight = gameHeight;
    this.x = Math.random() * gameWidth;
    this.y = Math.random() * gameHeight;
    this.size = Math.random() * 3 + 1;
    this.speedX = (Math.random() - 0.5) * 0.8;
    this.speedY = (Math.random() - 0.5) * 0.8;
    this.opacity = Math.random() * 0.4 + 0.1;
    this.pulseSpeed = Math.random() * 0.03 + 0.01;
    this.pulseOffset = Math.random() * Math.PI * 2;
    this.color = theme.particleColor;
  }

  update(_time: number) {
    this.x += this.speedX;
    this.y += this.speedY;

    if (this.x < 0) this.x = this.gameWidth;
    if (this.x > this.gameWidth) this.x = 0;
    if (this.y < 0) this.y = this.gameHeight;
    if (this.y > this.gameHeight) this.y = 0;
  }

  draw(ctx: CanvasRenderingContext2D, time: number) {
    const pulse = Math.sin(time * this.pulseSpeed + this.pulseOffset) * 0.3 + 0.7;
    
    ctx.save();
    ctx.globalAlpha = this.opacity * pulse;
    ctx.fillStyle = this.color;
    ctx.shadowColor = this.color;
    ctx.shadowBlur = 8;
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}

export class FloatingShape {
  x: number;
  y: number;
  size: number;
  rotation: number;
  rotationSpeed: number;
  speedX: number;
  speedY: number;
  opacity: number;
  type: number;
  color: string;
  gameWidth: number;
  gameHeight: number;

  constructor(theme: { particleColor: string }, gameWidth: number, gameHeight: number) {
    this.gameWidth = gameWidth;
    this.gameHeight = gameHeight;
    this.x = Math.random() * gameWidth;
    this.y = Math.random() * gameHeight;
    this.size = Math.random() * 50 + 30;
    this.rotation = Math.random() * Math.PI * 2;
    this.rotationSpeed = (Math.random() - 0.5) * 0.01;
    this.speedX = (Math.random() - 0.5) * 0.3;
    this.speedY = (Math.random() - 0.5) * 0.3;
    this.opacity = Math.random() * 0.08 + 0.02;
    this.type = Math.floor(Math.random() * 3);
    this.color = theme.particleColor;
  }

  update() {
    this.x += this.speedX;
    this.y += this.speedY;
    this.rotation += this.rotationSpeed;

    if (this.x < -this.size) this.x = this.gameWidth + this.size;
    if (this.x > this.gameWidth + this.size) this.x = -this.size;
    if (this.y < -this.size) this.y = this.gameHeight + this.size;
    if (this.y > this.gameHeight + this.size) this.y = -this.size;
  }

  draw(ctx: CanvasRenderingContext2D) {
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.rotate(this.rotation);
    ctx.globalAlpha = this.opacity;
    ctx.strokeStyle = this.color;
    ctx.lineWidth = 2;

    if (this.type === 0) {
      // Triangle
      ctx.beginPath();
      ctx.moveTo(0, -this.size / 2);
      ctx.lineTo(-this.size / 2, this.size / 2);
      ctx.lineTo(this.size / 2, this.size / 2);
      ctx.closePath();
      ctx.stroke();
    } else if (this.type === 1) {
      // Square
      ctx.strokeRect(-this.size / 2, -this.size / 2, this.size, this.size);
    } else {
      // Hexagon
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const angle = (Math.PI / 3) * i;
        const px = Math.cos(angle) * this.size / 2;
        const py = Math.sin(angle) * this.size / 2;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.stroke();
    }

    ctx.restore();
  }
}