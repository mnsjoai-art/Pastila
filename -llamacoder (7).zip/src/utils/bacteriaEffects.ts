export class BloodCell {
  x: number;
  y: number;
  vx: number;
  vy: number;
  rotation: number;
  rotationSpeed: number;
  size: number;
  width: number;
  height: number;
  type: "red" | "white";
  deformPhase: number;
  deformSpeed: number;
  brightness: number;

  constructor(width: number, height: number, type: "red" | "white" = "red") {
    this.width = width;
    this.height = height;
    this.type = type;
    this.x = Math.random() * width;
    this.y = Math.random() * height;
    this.vx = (Math.random() - 0.5) * 0.4;
    this.vy = (Math.random() - 0.5) * 0.4;
    this.rotation = Math.random() * Math.PI * 2;
    this.rotationSpeed = (Math.random() - 0.5) * 0.008;
    this.size = type === "red" ? Math.random() * 5 + 7 : Math.random() * 6 + 9;
    this.deformPhase = Math.random() * Math.PI * 2;
    this.deformSpeed = 0.02 + Math.random() * 0.02;
    this.brightness = 0.85 + Math.random() * 0.15;
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.rotation += this.rotationSpeed;
    this.deformPhase += this.deformSpeed;

    if (this.x < -this.size * 2) this.x = this.width + this.size;
    if (this.x > this.width + this.size * 2) this.x = -this.size;
    if (this.y < -this.size * 2) this.y = this.height + this.size;
    if (this.y > this.height + this.size * 2) this.y = -this.size;
  }

  draw(ctx: CanvasRenderingContext2D) {
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.rotate(this.rotation);

    const deform = Math.sin(this.deformPhase) * 0.15;
    const w = this.size * (1.8 + deform);
    const h = this.size * (0.55 - deform * 0.3);

    if (this.type === "red") {
      // Realistic red blood cell with biconcave disc shape
      const gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, w);
      gradient.addColorStop(0, `rgba(180, 20, 20, ${0.7 * this.brightness})`);
      gradient.addColorStop(0.3, `rgba(200, 35, 35, ${0.8 * this.brightness})`);
      gradient.addColorStop(0.6, `rgba(170, 25, 25, ${0.85 * this.brightness})`);
      gradient.addColorStop(0.85, `rgba(140, 15, 15, ${0.9 * this.brightness})`);
      gradient.addColorStop(1, `rgba(100, 10, 10, ${0.6 * this.brightness})`);

      // Main cell body
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.ellipse(0, 0, w, h, 0, 0, Math.PI * 2);
      ctx.fill();

      // Central depression (biconcave)
      const centerGradient = ctx.createRadialGradient(0, 0, 0, 0, 0, w * 0.4);
      centerGradient.addColorStop(0, `rgba(120, 15, 15, ${0.5 * this.brightness})`);
      centerGradient.addColorStop(0.5, `rgba(150, 20, 20, ${0.3 * this.brightness})`);
      centerGradient.addColorStop(1, "rgba(180, 30, 30, 0)");

      ctx.fillStyle = centerGradient;
      ctx.beginPath();
      ctx.ellipse(0, 0, w * 0.45, h * 0.5, 0, 0, Math.PI * 2);
      ctx.fill();

      // Highlight
      ctx.fillStyle = `rgba(255, 100, 100, ${0.15 * this.brightness})`;
      ctx.beginPath();
      ctx.ellipse(-w * 0.3, -h * 0.2, w * 0.25, h * 0.3, -0.3, 0, Math.PI * 2);
      ctx.fill();

      // Edge glow
      ctx.strokeStyle = `rgba(220, 60, 60, ${0.3 * this.brightness})`;
      ctx.lineWidth = 0.5;
      ctx.beginPath();
      ctx.ellipse(0, 0, w - 0.5, h - 0.5, 0, 0, Math.PI * 2);
      ctx.stroke();

    } else {
      // White blood cell (neutrophil) - round with granular texture
      const baseGradient = ctx.createRadialGradient(0, 0, 0, 0, 0, this.size);
      baseGradient.addColorStop(0, `rgba(245, 245, 250, ${0.9 * this.brightness})`);
      baseGradient.addColorStop(0.5, `rgba(235, 235, 240, ${0.85 * this.brightness})`);
      baseGradient.addColorStop(0.8, `rgba(220, 220, 230, ${0.8 * this.brightness})`);
      baseGradient.addColorStop(1, `rgba(200, 200, 210, ${0.7 * this.brightness})`);

      // Cell body
      ctx.fillStyle = baseGradient;
      ctx.beginPath();
      ctx.arc(0, 0, this.size, 0, Math.PI * 2);
      ctx.fill();

      // Granules inside
      const granuleCount = 15;
      for (let i = 0; i < granuleCount; i++) {
        const angle = (i / granuleCount) * Math.PI * 2 + this.deformPhase * 0.5;
        const dist = Math.random() * this.size * 0.6;
        const gx = Math.cos(angle) * dist;
        const gy = Math.sin(angle) * dist;
        const gSize = 0.8 + Math.random() * 1.2;
        
        ctx.fillStyle = `rgba(180, 180, 200, ${0.3 * this.brightness})`;
        ctx.beginPath();
        ctx.arc(gx, gy, gSize, 0, Math.PI * 2);
        ctx.fill();
      }

      // Multi-lobed nucleus
      const nucleusGradient = ctx.createRadialGradient(0, 0, 0, 0, 0, this.size * 0.5);
      nucleusGradient.addColorStop(0, `rgba(120, 100, 140, ${0.7 * this.brightness})`);
      nucleusGradient.addColorStop(0.6, `rgba(100, 80, 120, ${0.6 * this.brightness})`);
      nucleusGradient.addColorStop(1, `rgba(80, 60, 100, ${0.4 * this.brightness})`);

      ctx.fillStyle = nucleusGradient;
      
      // Draw lobes
      const lobeCount = 3;
      for (let i = 0; i < lobeCount; i++) {
        const angle = (i / lobeCount) * Math.PI * 2 + this.deformPhase * 0.3;
        const lobeX = Math.cos(angle) * this.size * 0.25;
        const lobeY = Math.sin(angle) * this.size * 0.2;
        const lobeSize = this.size * 0.35;
        
        ctx.beginPath();
        ctx.arc(lobeX, lobeY, lobeSize, 0, Math.PI * 2);
        ctx.fill();
      }

      // Membrane texture
      ctx.strokeStyle = `rgba(180, 180, 200, ${0.2 * this.brightness})`;
      ctx.lineWidth = 0.5;
      ctx.beginPath();
      ctx.arc(0, 0, this.size - 0.5, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.restore();
  }
}

export class Bacteria {
  x: number;
  y: number;
  vx: number;
  vy: number;
  rotation: number;
  rotationSpeed: number;
  size: number;
  width: number;
  height: number;
  type: number;
  flagellaPhase: number;
  brightness: number;

  constructor(width: number, height: number) {
    this.width = width;
    this.height = height;
    this.x = Math.random() * width;
    this.y = Math.random() * height;
    this.vx = (Math.random() - 0.5) * 0.6;
    this.vy = (Math.random() - 0.5) * 0.6;
    this.rotation = Math.random() * Math.PI * 2;
    this.rotationSpeed = (Math.random() - 0.5) * 0.01;
    this.size = Math.random() * 6 + 5;
    this.type = Math.floor(Math.random() * 3);
    this.flagellaPhase = Math.random() * Math.PI * 2;
    this.brightness = 0.8 + Math.random() * 0.2;
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.rotation += this.rotationSpeed;
    this.flagellaPhase += 0.15;

    if (this.x < -this.size * 2) this.x = this.width + this.size;
    if (this.x > this.width + this.size * 2) this.x = -this.size;
    if (this.y < -this.size * 2) this.y = this.height + this.size;
    if (this.y > this.height + this.size * 2) this.y = -this.size;
  }

  draw(ctx: CanvasRenderingContext2D) {
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.rotate(this.rotation);

    if (this.type === 0) {
      // E. coli - rod-shaped
      const gradient = ctx.createLinearGradient(-this.size, 0, this.size, 0);
      gradient.addColorStop(0, `rgba(80, 140, 80, ${0.7 * this.brightness})`);
      gradient.addColorStop(0.5, `rgba(100, 160, 100, ${0.8 * this.brightness})`);
      gradient.addColorStop(1, `rgba(70, 120, 70, ${0.7 * this.brightness})`);

      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.roundRect(-this.size, -this.size * 0.35, this.size * 2, this.size * 0.7, this.size * 0.35);
      ctx.fill();

      // Flagella
      ctx.strokeStyle = `rgba(120, 180, 120, ${0.5 * this.brightness})`;
      ctx.lineWidth = 0.8;
      for (let i = 0; i < 3; i++) {
        ctx.beginPath();
        ctx.moveTo(this.size, 0);
        for (let j = 0; j < 20; j++) {
          const x = this.size + j * 1.5;
          const y = Math.sin(this.flagellaPhase + j * 0.5 + i) * 3;
          ctx.lineTo(x, y);
        }
        ctx.stroke();
      }

    } else if (this.type === 1) {
      // Staphylococcus - spherical clusters
      const gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, this.size);
      gradient.addColorStop(0, `rgba(220, 180, 100, ${0.8 * this.brightness})`);
      gradient.addColorStop(0.7, `rgba(200, 160, 80, ${0.7 * this.brightness})`);
      gradient.addColorStop(1, `rgba(180, 140, 60, ${0.5 * this.brightness})`);

      // Draw cluster of spheres
      for (let i = 0; i < 4; i++) {
        const angle = (i / 4) * Math.PI * 2;
        const cx = Math.cos(angle) * this.size * 0.3;
        const cy = Math.sin(angle) * this.size * 0.3;
        
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(cx, cy, this.size * 0.5, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(0, 0, this.size * 0.5, 0, Math.PI * 2);
      ctx.fill();

    } else {
      // Streptococcus - chain
      const gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, this.size * 0.4);
      gradient.addColorStop(0, `rgba(180, 100, 100, ${0.8 * this.brightness})`);
      gradient.addColorStop(0.7, `rgba(160, 80, 80, ${0.7 * this.brightness})`);
      gradient.addColorStop(1, `rgba(140, 60, 60, ${0.5 * this.brightness})`);

      for (let i = -2; i <= 2; i++) {
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(i * this.size * 0.7, 0, this.size * 0.4, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    ctx.restore();
  }
}

export class Virus {
  x: number;
  y: number;
  vx: number;
  vy: number;
  rotation: number;
  rotationSpeed: number;
  size: number;
  width: number;
  height: number;
  spikePhase: number;
  brightness: number;
  type: number;

  constructor(width: number, height: number) {
    this.width = width;
    this.height = height;
    this.x = Math.random() * width;
    this.y = Math.random() * height;
    this.vx = (Math.random() - 0.5) * 0.3;
    this.vy = (Math.random() - 0.5) * 0.3;
    this.rotation = Math.random() * Math.PI * 2;
    this.rotationSpeed = (Math.random() - 0.5) * 0.008;
    this.size = Math.random() * 8 + 10;
    this.spikePhase = Math.random() * Math.PI * 2;
    this.brightness = 0.85 + Math.random() * 0.15;
    this.type = Math.floor(Math.random() * 2);
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.rotation += this.rotationSpeed;
    this.spikePhase += 0.05;

    if (this.x < -this.size * 2) this.x = this.width + this.size;
    if (this.x > this.width + this.size * 2) this.x = -this.size;
    if (this.y < -this.size * 2) this.y = this.height + this.size;
    if (this.y > this.height + this.size * 2) this.y = -this.size;
  }

  draw(ctx: CanvasRenderingContext2D) {
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.rotate(this.rotation);

    if (this.type === 0) {
      // Coronavirus style
      const envelopeGradient = ctx.createRadialGradient(0, 0, 0, 0, 0, this.size);
      envelopeGradient.addColorStop(0, `rgba(100, 140, 100, ${0.6 * this.brightness})`);
      envelopeGradient.addColorStop(0.5, `rgba(80, 120, 80, ${0.7 * this.brightness})`);
      envelopeGradient.addColorStop(0.8, `rgba(60, 100, 60, ${0.8 * this.brightness})`);
      envelopeGradient.addColorStop(1, `rgba(40, 80, 40, ${0.5 * this.brightness})`);

      // Envelope
      ctx.fillStyle = envelopeGradient;
      ctx.beginPath();
      ctx.arc(0, 0, this.size, 0, Math.PI * 2);
      ctx.fill();

      // Inner membrane
      const innerGradient = ctx.createRadialGradient(0, 0, 0, 0, 0, this.size * 0.7);
      innerGradient.addColorStop(0, `rgba(60, 90, 60, ${0.5 * this.brightness})`);
      innerGradient.addColorStop(1, "rgba(80, 110, 80, 0)");
      ctx.fillStyle = innerGradient;
      ctx.beginPath();
      ctx.arc(0, 0, this.size * 0.7, 0, Math.PI * 2);
      ctx.fill();

      // Spike proteins (crown)
      const spikeCount = 16;
      for (let i = 0; i < spikeCount; i++) {
        const angle = (i / spikeCount) * Math.PI * 2;
        const spikeWave = Math.sin(this.spikePhase + i * 0.5) * 0.15 + 1;
        const spikeLength = this.size * 0.4 * spikeWave;
        
        const baseX = Math.cos(angle) * this.size;
        const baseY = Math.sin(angle) * this.size;
        const tipX = Math.cos(angle) * (this.size + spikeLength);
        const tipY = Math.sin(angle) * (this.size + spikeLength);

        // Spike shaft
        ctx.strokeStyle = `rgba(120, 160, 120, ${0.7 * this.brightness})`;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(baseX, baseY);
        ctx.lineTo(tipX, tipY);
        ctx.stroke();

        // Spike ball (glycoprotein)
        const ballGradient = ctx.createRadialGradient(tipX, tipY, 0, tipX, tipY, 3);
        ballGradient.addColorStop(0, `rgba(150, 190, 150, ${0.9 * this.brightness})`);
        ballGradient.addColorStop(1, `rgba(100, 140, 100, ${0.6 * this.brightness})`);
        ctx.fillStyle = ballGradient;
        ctx.beginPath();
        ctx.arc(tipX, tipY, 2.5, 0, Math.PI * 2);
        ctx.fill();
      }

    } else {
      // Influenza virus
      const envelopeGradient = ctx.createRadialGradient(0, 0, 0, 0, 0, this.size);
      envelopeGradient.addColorStop(0, `rgba(140, 100, 100, ${0.6 * this.brightness})`);
      envelopeGradient.addColorStop(0.5, `rgba(120, 80, 80, ${0.7 * this.brightness})`);
      envelopeGradient.addColorStop(1, `rgba(100, 60, 60, ${0.5 * this.brightness})`);

      ctx.fillStyle = envelopeGradient;
      ctx.beginPath();
      ctx.arc(0, 0, this.size, 0, Math.PI * 2);
      ctx.fill();

      // Surface proteins (HA and NA)
      const proteinCount = 20;
      for (let i = 0; i < proteinCount; i++) {
        const angle = (i / proteinCount) * Math.PI * 2;
        const r = this.size * (0.85 + Math.random() * 0.15);
        const px = Math.cos(angle) * r;
        const py = Math.sin(angle) * r;
        
        ctx.fillStyle = `rgba(180, 140, 140, ${0.6 * this.brightness})`;
        ctx.beginPath();
        ctx.arc(px, py, 1.5, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    ctx.restore();
  }
}

export class Platelet {
  x: number;
  y: number;
  vx: number;
  vy: number;
  rotation: number;
  rotationSpeed: number;
  size: number;
  width: number;
  height: number;
  deformPhase: number;
  brightness: number;

  constructor(width: number, height: number) {
    this.width = width;
    this.height = height;
    this.x = Math.random() * width;
    this.y = Math.random() * height;
    this.vx = (Math.random() - 0.5) * 0.35;
    this.vy = (Math.random() - 0.5) * 0.35;
    this.rotation = Math.random() * Math.PI * 2;
    this.rotationSpeed = (Math.random() - 0.5) * 0.01;
    this.size = Math.random() * 3 + 3;
    this.deformPhase = Math.random() * Math.PI * 2;
    this.brightness = 0.85 + Math.random() * 0.15;
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.rotation += this.rotationSpeed;
    this.deformPhase += 0.03;

    if (this.x < -this.size * 2) this.x = this.width + this.size;
    if (this.x > this.width + this.size * 2) this.x = -this.size;
    if (this.y < -this.size * 2) this.y = this.height + this.size;
    if (this.y > this.height + this.size * 2) this.y = -this.size;
  }

  draw(ctx: CanvasRenderingContext2D) {
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.rotate(this.rotation);

    const deform = Math.sin(this.deformPhase) * 0.1;

    // Platelet - small irregular shape
    const gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, this.size);
    gradient.addColorStop(0, `rgba(230, 220, 200, ${0.8 * this.brightness})`);
    gradient.addColorStop(0.5, `rgba(210, 200, 180, ${0.7 * this.brightness})`);
    gradient.addColorStop(1, `rgba(190, 180, 160, ${0.5 * this.brightness})`);

    ctx.fillStyle = gradient;
    ctx.beginPath();
    
    // Irregular shape
    const points = 6;
    for (let i = 0; i <= points; i++) {
      const angle = (i / points) * Math.PI * 2;
      const r = this.size * (0.8 + Math.sin(this.deformPhase + i * 2) * 0.2 + deform);
      const px = Math.cos(angle) * r;
      const py = Math.sin(angle) * r;
      
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fill();

    // Granules
    for (let i = 0; i < 4; i++) {
      const gx = (Math.random() - 0.5) * this.size * 0.6;
      const gy = (Math.random() - 0.5) * this.size * 0.6;
      ctx.fillStyle = `rgba(180, 170, 150, ${0.4 * this.brightness})`;
      ctx.beginPath();
      ctx.arc(gx, gy, 0.8, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();
  }
}