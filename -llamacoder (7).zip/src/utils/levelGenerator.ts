import { LevelData, Obstacle } from "../App";

const GAME_WIDTH = 600;
const GAME_HEIGHT = 500;

const LEVEL_THEMES = [
  { primary: "#22c55e", secondary: "#4ade80", accent: "#86efac", particleColor: "#4ade80", name: "Green" },
  { primary: "#10b981", secondary: "#34d399", accent: "#6ee7b7", particleColor: "#34d399", name: "Emerald" },
  { primary: "#14b8a6", secondary: "#2dd4bf", accent: "#5eead4", particleColor: "#2dd4bf", name: "Teal" },
  { primary: "#059669", secondary: "#10b981", accent: "#34d399", particleColor: "#10b981", name: "Dark Green" },
  { primary: "#84cc16", secondary: "#a3e635", accent: "#bef264", particleColor: "#a3e635", name: "Lime" },
];

const LEVEL_NAMES = [
  "First Dose",
  "Mild Case",
  "Spreading",
  "Infection",
  "Bacteria",
  "Virus",
  "Outbreak",
  "Epidemic",
  "Pandemic",
  "Critical",
  "Emergency",
  "Quarantine",
  "Containment",
  "Treatment",
  "Recovery",
  "Immunity",
  "Vaccinated",
  "Cured",
  "Healthy",
  "Champion"
];

class SeededRandom {
  private seed: number;
  
  constructor(seed: number) {
    this.seed = seed;
  }
  
  next(): number {
    this.seed = (this.seed * 1103515245 + 12345) & 0x7fffffff;
    return this.seed / 0x7fffffff;
  }
  
  range(min: number, max: number): number {
    return min + this.next() * (max - min);
  }
  
  int(min: number, max: number): number {
    return Math.floor(this.range(min, max));
  }
  
  chance(probability: number): boolean {
    return this.next() < probability;
  }
}

export function generateLevel(levelNumber: number): LevelData {
  const seed = levelNumber * 12345 + 67890;
  const rng = new SeededRandom(seed);
  
  const obstacles: Obstacle[] = [];
  const themeIndex = (levelNumber - 1) % LEVEL_THEMES.length;
  const theme = LEVEL_THEMES[themeIndex];
  
  const ballStart = {
    x: 300,
    y: 420
  };
  
  const portalPositions = [
    { x: 300, y: 80 },
    { x: 100, y: 80 },
    { x: 500, y: 80 },
    { x: 300, y: 150 },
    { x: 150, y: 120 },
    { x: 450, y: 120 },
  ];
  const portal = portalPositions[(levelNumber - 1) % portalPositions.length];
  
  const numObstacles = Math.min(2 + Math.floor(levelNumber / 3), 8);
  
  for (let i = 0; i < numObstacles; i++) {
    const obstacleType = rng.chance(0.7) ? "solid" : 
                          rng.chance(0.5) ? "bouncy" : "sticky";
    
    const width = rng.range(80, 150);
    const height = 16;
    const x = rng.range(50, GAME_WIDTH - width - 50);
    const y = rng.range(100, GAME_HEIGHT - 150);
    const angle = rng.range(-30, 30);
    
    const distToBall = Math.sqrt(Math.pow(x + width/2 - ballStart.x, 2) + Math.pow(y + height/2 - ballStart.y, 2));
    const distToPortal = Math.sqrt(Math.pow(x + width/2 - portal.x, 2) + Math.pow(y + height/2 - portal.y, 2));
    
    if (distToBall > 60 && distToPortal > 60) {
      obstacles.push({
        x,
        y,
        width,
        height,
        type: obstacleType,
        angle
      });
    }
  }
  
  if (levelNumber >= 10 && levelNumber % 3 === 1) {
    const teleporterId = levelNumber;
    obstacles.push({
      x: 80,
      y: 200,
      width: 40,
      height: 40,
      type: "teleporter",
      teleporterId
    });
    obstacles.push({
      x: 480,
      y: 300,
      width: 40,
      height: 40,
      type: "teleporter",
      teleporterId
    });
  }
  
  const maxBounces = 25 + levelNumber * 2;
  
  return {
    id: levelNumber,
    name: LEVEL_NAMES[Math.min(levelNumber - 1, LEVEL_NAMES.length - 1)],
    obstacles,
    portal,
    maxBounces,
    ballStart,
    theme
  };
}