let audioContext: AudioContext | null = null;

export function initAudio() {
  if (!audioContext) {
    audioContext = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
  }
  return audioContext;
}

function playTone(frequency: number, duration: number, type: OscillatorType = "sine", volume: number = 0.15) {
  const ctx = initAudio();
  if (!ctx) return;

  const oscillator = ctx.createOscillator();
  const gainNode = ctx.createGain();

  oscillator.connect(gainNode);
  gainNode.connect(ctx.destination);

  oscillator.frequency.value = frequency;
  oscillator.type = type;
  gainNode.gain.setValueAtTime(volume, ctx.currentTime);
  gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

  oscillator.start(ctx.currentTime);
  oscillator.stop(ctx.currentTime + duration);
}

export const playSound = {
  bounce: () => playTone(320, 0.08, "sine", 0.12),
  shoot: () => {
    playTone(380, 0.1, "sine", 0.15);
    playTone(480, 0.08, "sine", 0.1);
  },
  portal: () => {
    playTone(523, 0.15, "sine", 0.2);
    playTone(659, 0.15, "sine", 0.15);
    playTone(784, 0.2, "sine", 0.1);
  },
  levelComplete: () => {
    playTone(523, 0.1, "sine", 0.2);
    setTimeout(() => playTone(659, 0.1, "sine", 0.2), 100);
    setTimeout(() => playTone(784, 0.15, "sine", 0.2), 200);
    setTimeout(() => playTone(1047, 0.2, "sine", 0.2), 300);
  },
  gameOver: () => {
    playTone(294, 0.2, "sawtooth", 0.15);
    setTimeout(() => playTone(262, 0.3, "sawtooth", 0.12), 150);
  },
  bouncyHit: () => playTone(494, 0.12, "sine", 0.15),
  stickyHit: () => playTone(196, 0.15, "triangle", 0.12),
  teleport: () => {
    playTone(880, 0.1, "sine", 0.15);
    playTone(1320, 0.15, "sine", 0.1);
  },
};