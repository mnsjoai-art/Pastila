import { useState, useEffect } from "react";

interface Keys {
  left: boolean;
  right: boolean;
}

export function useKeyboard(): Keys {
  const [keys, setKeys] = useState<Keys>({ left: false, right: false });

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft" || e.key === "a") {
        setKeys((prev) => ({ ...prev, left: true }));
      }
      if (e.key === "ArrowRight" || e.key === "d") {
        setKeys((prev) => ({ ...prev, right: true }));
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft" || e.key === "a") {
        setKeys((prev) => ({ ...prev, left: false }));
      }
      if (e.key === "ArrowRight" || e.key === "d") {
        setKeys((prev) => ({ ...prev, right: false }));
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, []);

  return keys;
}